// iluminacion.h
// ---------------------------------------------------------------------------
// Descripción de las luces de la escena y cómo se envían al shader
// (escena.fs). Aquí solo hay datos: dónde está cada luz y de qué color. Los
// cálculos de luz ocurren en la GPU, en escena.fs.
//
// Hay tres ingredientes, de menor a mayor "personalidad":
//   1. Luz ambiente : un mínimo de luz que llega de todos lados (nada queda negro).
//   2. El Sol       : luz direccional (rayos paralelos, sin pérdida por distancia).
//   3. Bombillas    : luces puntuales (salen de un punto y se debilitan con la distancia).
// ---------------------------------------------------------------------------
#ifndef ILUMINACION_H
#define ILUMINACION_H

#include <learnopengl/shader_m.h>

#include <glm/glm.hpp>

#include <vector>

// El Sol está tan lejos que todos sus rayos llegan paralelos: no tiene
// posición, solo la dirección hacia la que viajan.
struct LuzSolar
{
    glm::vec3 direccion;   // hacia dónde viaja la luz (del Sol hacia la escena)
    glm::vec3 color;       // color de la luz; multiplícalo por >1 o <1 para darle intensidad
};

// Una bombilla: ilumina en todas direcciones desde un punto.
struct LuzPuntual
{
    glm::vec3 posicion;
    glm::vec3 color;

    // La luz se debilita con la distancia d según:
    //     atenuacion = 1 / (constante + lineal * d + cuadratica * d^2)
    // Los valores por defecto alcanzan unas 20 unidades (ver tabla de LearnOpenGL,
    // capítulo "Light casters"). Más grandes = la luz se apaga más cerca.
    float constante  = 1.0f;
    float lineal     = 0.22f;
    float cuadratica = 0.20f;
};

struct Iluminacion
{
    // Debe coincidir con MAX_LUCES_PUNTUALES en escena.fs.
    static constexpr int MAX_LUCES_PUNTUALES = 12;

    glm::vec3 ambiente;
    LuzSolar sol;
    std::vector<LuzPuntual> luces;

    // Envía todas las luces al shader. Hay que llamarlo con ese shader activo
    // (shader.use()). Las bombillas que sobren del máximo se ignoran.
    void enviarA(const Shader& shader) const;
};

// Cómo responde una superficie al brillo (la parte "pintura" ya viene en el
// color de cada vértice).
struct Material
{
    float intensidadEspecular;  // 0 = mate (piso) ... 1 = muy reflectante
    float brillo;               // tamaño del reflejo: bajo = amplio y suave, alto = pequeño y fuerte

    void enviarA(const Shader& shader) const;
};

#endif
