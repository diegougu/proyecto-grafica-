#version 330 core

// Atributos de cada vértice (ver la clase Malla, malla.cpp).
layout (location = 0) in vec3 aPosicion;
layout (location = 1) in vec3 aNormal;
layout (location = 2) in vec3 aColor;
layout (location = 3) in vec2 aUV;

// Lo que recibe escena.fs (ya interpolado entre los 3 vértices del triángulo).
out vec3 PosicionMundo;
out vec3 NormalMundo;
out vec3 ColorVertice;
out vec2 UV;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    PosicionMundo = vec3(model * vec4(aPosicion, 1.0));

    // Si el objeto se escala o estira, las normales no se transforman con "model"
    // directamente: hay que usar su inversa traspuesta para que sigan siendo perpendiculares.
    NormalMundo = mat3(transpose(inverse(model))) * aNormal;

    ColorVertice = aColor;
    UV = aUV;

    gl_Position = projection * view * vec4(PosicionMundo, 1.0);
}
