//========================================================================
// OpenGL triangle example
// Copyright (c) Camilla Löwy <elmindreda@glfw.org>
//
// This software is provided 'as-is', without any express or implied
// warranty. In no event will the authors be held liable for any damages
// arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it
// freely, subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented; you must not
//    claim that you wrote the original software. If you use this software
//    in a product, an acknowledgment in the product documentation would
//    be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such, and must not
//    be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source
//    distribution.
//
//========================================================================

// ---------------------------------------------------------------------------
// ESCENA: carrusel (modelo OBJ) + piso + Sol + bombillas, con modo día/noche.
// (Versión modificada del ejemplo original; el original quedó respaldado en
//  original_learnopengl/main_basic_lighting.cpp.txt)
//
// Cómo está organizado el proyecto:
//   main.cpp         Ventana, cámara y bucle de dibujo (este archivo).
//   malla.*          Triángulos en la GPU + generadores del piso y la esfera.
//   modelo_obj.*     Lee un modelo OBJ/MTL y lo divide en piezas (una Malla por material).
//   textura.*        Carga una imagen (PNG, JPG...) en la GPU.
//   iluminacion.*    Datos de las luces (ambiente, Sol, bombillas) y material.
//   escena.vs/.fs    Shader de los objetos iluminados (aquí se calcula la luz).
//   emisivo.vs/.fs   Shader de los objetos que emiten luz (Sol y bombillas).
//
// Controles: W A S D mover la cámara | ratón mirar | rueda zoom | N día/noche | ESC salir.
// ---------------------------------------------------------------------------

#include <glad/glad.h>

#define GLFW_INCLUDE_NONE
#include <GLFW/glfw3.h>

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

#include <learnopengl/shader_m.h>
#include <learnopengl/camera.h>

#include "iluminacion.h"
#include "malla.h"
#include "modelo_obj.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

// ===========================================================================
//  CONFIGURACIÓN DE LA ESCENA  (aquí es donde conviene probar cambios)
// ===========================================================================

// --- Ventana ---------------------------------------------------------------
const unsigned int ANCHO_VENTANA = 800;
const unsigned int ALTO_VENTANA  = 600;

// --- Modelo ----------------------------------------------------------------
// Carrusel "Xuan_Zhuan_Mu_Ma": ~2 millones de triángulos. Los caballos se pintan con las
// imágenes que nombra su .mtl (ma_color_a.jpg...), que deben estar junto al .obj.
const char* const RUTA_MODELO = "modelos/Xuan_Zhuan_Mu_Ma.obj";

// Altura que tendrá en el mundo; el ancho se ajusta solo. El modelo se dibuja
// centrado en el origen y con su base sobre el piso (y = 0).
const float ALTURA_MODELO = 7.5f;

// Grupos del OBJ que NO se dibujan (restos de la escena original de Maya).
const std::vector<std::string> GRUPOS_IGNORADOS = {
    "pSphere1",    // cúpula de cielo: encerraría todo lo demás
    "pPlane1",     // plano "atrapa sombras" del render original: se encimaría con nuestro piso
};

// --- Aspecto del carrusel --------------------------------------------------
// El MTL de este modelo perdió datos al exportarse desde Maya: los paneles salen sin su
// ilustración, el piso de la plataforma sale negro y los colores no son los del render
// original del modelo (techo carmesí y amarillo, no púrpura y rojo). Ver darAspectoAlCarrusel().
const glm::vec3 COLOR_CARMESI (0.90f, 0.08f, 0.32f);    // base, corona y gajos del techo
const glm::vec3 COLOR_AMARILLO(1.00f, 0.80f, 0.10f);    // el otro color de los gajos del techo y del piso
const int FRANJAS_DE_LA_PLATAFORMA = 20;                // gajos del piso de la plataforma (debe ser par)
const glm::vec3 COLOR_BOMBILLAS_ENCENDIDAS(1.0f, 0.82f, 0.45f);

// Materiales del modelo que son luces encendidas. Su brillo propio cambia entre el día y la noche
// (ver Ambiente), por eso se nombran aquí y no dentro de darAspectoAlCarrusel().
const std::array<const char*, 2> PANELES_ILUSTRADOS = {"rsIncandescent1SG", "rsIncandescent2SG"};
const std::array<const char*, 4> BOMBILLAS_DEL_MODELO = {"rsIncandescent4SG", "rsIncandescent5SG",
                                                         "rsIncandescent6SG", "rsIncandescent7SG"};

// --- Día y noche (tecla N) -------------------------------------------------
// Todo lo que cambia entre el día y la noche, junto en un solo lugar. Al pulsar N la escena pasa
// poco a poco de DIA a NOCHE (o al revés): cada valor se va mezclando entre los dos.
struct Ambiente
{
    glm::vec3 colorCielo;
    glm::vec3 luzAmbiente;         // luz mínima que llega de todos lados
    glm::vec3 luzDelSol;           // luz direccional (de noche: luz de luna, muy tenue)
    glm::vec3 colorDelDisco;       // color del disco del cielo (de noche: una luna pálida)
    float intensidadBombillas;     // multiplica la luz de las 12 bombillas (1 = tal como están definidas)
    float luzPropiaBombillas;      // brillo propio de las bombillas del modelo: 0 apagadas ... 1 muy brillantes
    float luzPropiaPaneles;        // cuánto brillan por sí solas las ilustraciones
};

const Ambiente DIA = {
    glm::vec3(0.55f, 0.70f, 0.90f),    // cielo azul
    glm::vec3(0.22f, 0.25f, 0.32f),    // un poco azulada, como la luz del cielo
    glm::vec3(1.00f, 0.93f, 0.75f),    // Sol: blanco cálido
    glm::vec3(1.00f, 0.93f, 0.75f),
    1.0f, 0.9f, 0.2f,
};
const Ambiente NOCHE = {
    glm::vec3(0.02f, 0.03f, 0.08f),    // cielo azul muy oscuro
    glm::vec3(0.05f, 0.06f, 0.11f),
    glm::vec3(0.08f, 0.11f, 0.20f),    // luz de luna, tenue y azulada
    glm::vec3(0.80f, 0.85f, 1.00f),    // la luna
    2.2f, 1.1f, 0.9f,                  // las luces del carrusel destacan: bombillas más fuertes y paneles que brillan
};
const bool  EMPEZAR_DE_NOCHE       = false;
const float SEGUNDOS_DE_TRANSICION = 2.5f;

// --- Sol (luz direccional) -------------------------------------------------
// Dirección DESDE el centro de la escena HACIA el Sol (x, y, z): el Sol queda
// a la derecha, delante y bastante alto. Los rayos viajan en sentido contrario.
// (De noche, ese mismo punto del cielo lo ocupa la luna.) Los colores están en DIA y NOCHE.
const glm::vec3 HACIA_EL_SOL = glm::normalize(glm::vec3(0.45f, 0.55f, 0.70f));
const float DISTANCIA_SOL = 35.0f;                    // solo afecta a cómo se DIBUJA el disco
const float RADIO_SOL     = 2.0f;

// --- Bombillas (luces puntuales) -------------------------------------------
// Doce luces repartidas en un círculo a la altura del borde del techo: iluminan el
// carrusel desde donde están las bombillas que el modelo ya trae. Los colores de la
// lista se repiten en orden hasta completar CANTIDAD_BOMBILLAS.
const int CANTIDAD_BOMBILLAS = 12;   // máximo permitido: Iluminacion::MAX_LUCES_PUNTUALES
const std::array<glm::vec3, 3> COLORES_BOMBILLAS = {{
    glm::vec3(1.00f, 0.80f, 0.45f),   // ámbar claro
    glm::vec3(1.00f, 0.68f, 0.34f),   // naranja cálido
    glm::vec3(1.00f, 0.92f, 0.65f),   // amarillo pálido
}};
const float RADIO_CIRCULO_BOMBILLAS = 3.5f;
const float ALTURA_BOMBILLAS        = 4.0f;
const bool  DIBUJAR_ESFERAS_DE_LUZ  = false;   // true: marca cada luz con una esfera (útil para ubicarlas)
const float RADIO_BOMBILLA          = 0.12f;   // tamaño de esas esferas
// Qué tan rápido se debilita la luz con la distancia (ver LuzPuntual en iluminacion.h).
// Estos valores equivalen a un alcance de ~13 unidades; súbelos para que cada bombilla ilumine menos lejos.
const float ATENUACION_LINEAL     = 0.35f;
const float ATENUACION_CUADRATICA = 0.44f;

// --- Piso ------------------------------------------------------------------
const float LADO_PISO        = 80.0f;
const int   CASILLAS_PISO    = 40;
const glm::vec3 COLOR_PISO_A(0.60f, 0.58f, 0.52f);
const glm::vec3 COLOR_PISO_B(0.50f, 0.48f, 0.43f);

// --- Materiales ------------------------------------------------------------
const Material MATERIAL_MODELO = {0.35f, 32.0f};      // pintura algo brillante
const Material MATERIAL_PISO   = {0.05f,  8.0f};      // casi mate

// --- Cámara ----------------------------------------------------------------
// Arranca a cierta distancia, un poco por encima del suelo y mirando al carrusel.
Camera camara(glm::vec3(11.0f, 5.0f, 15.0f), glm::vec3(0.0f, 1.0f, 0.0f), -126.0f, -5.0f);
const float VELOCIDAD_CAMARA = 6.0f;   // unidades del mundo por segundo (con W A S D)

// ===========================================================================
//  ESTADO DE LA APLICACIÓN
// ===========================================================================

float aspecto = static_cast<float>(ANCHO_VENTANA) / ALTO_VENTANA;   // se actualiza si cambia el tamaño de la ventana

float ultimoX = ANCHO_VENTANA / 2.0f;
float ultimoY = ALTO_VENTANA / 2.0f;
bool  primerMovimientoMouse = true;

float deltaTiempo = 0.0f;   // segundos que duró el cuadro anterior
float ultimoCuadro = 0.0f;

// Día y noche: esDeNoche es lo que pidió el usuario (tecla N); nocturnidad es cuánta noche se ve
// en este momento (0 = día completo ... 1 = noche completa) y se acerca poco a poco a esDeNoche.
bool  esDeNoche   = EMPEZAR_DE_NOCHE;
float nocturnidad = EMPEZAR_DE_NOCHE ? 1.0f : 0.0f;

// ===========================================================================
//  FUNCIONES
// ===========================================================================

void framebuffer_size_callback(GLFWwindow* ventana, int ancho, int alto);
void mouse_callback(GLFWwindow* ventana, double xpos, double ypos);
void scroll_callback(GLFWwindow* ventana, double xoffset, double yoffset);
void key_callback(GLFWwindow* ventana, int tecla, int codigoDeTecla, int accion, int modificadores);
void procesarEntrada(GLFWwindow* ventana);

// Coloca el Sol y las bombillas en un solo objeto, listo para enviar al shader. Aquí solo van sus
// posiciones y su alcance; los colores e intensidades cambian entre el día y la noche, así que los
// fija aplicarAmbiente() en cada cuadro.
Iluminacion crearIluminacion()
{
    Iluminacion iluminacion;
    iluminacion.sol.direccion = -HACIA_EL_SOL;

    const float dosPi = 6.28318530718f;
    for (int i = 0; i < CANTIDAD_BOMBILLAS; ++i)
    {
        const float angulo = dosPi * i / CANTIDAD_BOMBILLAS;

        LuzPuntual bombilla;
        bombilla.posicion = glm::vec3(RADIO_CIRCULO_BOMBILLAS * std::cos(angulo),
                                      ALTURA_BOMBILLAS,
                                      RADIO_CIRCULO_BOMBILLAS * std::sin(angulo));
        bombilla.lineal = ATENUACION_LINEAL;
        bombilla.cuadratica = ATENUACION_CUADRATICA;
        iluminacion.luces.push_back(bombilla);
    }
    return iluminacion;
}

// Mezcla dos ambientes: con t = 0 resulta "a" (el día) y con t = 1 resulta "b" (la noche).
Ambiente mezclar(const Ambiente& a, const Ambiente& b, float t)
{
    return {
        glm::mix(a.colorCielo,   b.colorCielo,   t),
        glm::mix(a.luzAmbiente,  b.luzAmbiente,  t),
        glm::mix(a.luzDelSol,    b.luzDelSol,    t),
        glm::mix(a.colorDelDisco, b.colorDelDisco, t),
        glm::mix(a.intensidadBombillas, b.intensidadBombillas, t),
        glm::mix(a.luzPropiaBombillas,  b.luzPropiaBombillas,  t),
        glm::mix(a.luzPropiaPaneles,    b.luzPropiaPaneles,    t),
    };
}

// Aplica un ambiente a las luces y al modelo. Se llama en cada cuadro, porque durante la
// transición entre el día y la noche los valores van cambiando.
void aplicarAmbiente(const Ambiente& ambiente, Iluminacion& iluminacion, ModeloOBJ& carrusel)
{
    iluminacion.ambiente = ambiente.luzAmbiente;
    iluminacion.sol.color = ambiente.luzDelSol;

    for (size_t i = 0; i < iluminacion.luces.size(); ++i)
        iluminacion.luces[i].color = COLORES_BOMBILLAS[i % COLORES_BOMBILLAS.size()] * ambiente.intensidadBombillas;

    // Brillo propio de las piezas "encendidas" del modelo.
    for (const char* material : PANELES_ILUSTRADOS)
        carrusel.ponerLuzPropia(material, ambiente.luzPropiaPaneles);
    for (const char* material : BOMBILLAS_DEL_MODELO)
        carrusel.ponerLuzPropia(material, ambiente.luzPropiaBombillas);
}

// Devuelve al carrusel el aspecto que tenía en el render original del modelo. Los nombres son los
// de sus materiales en el .mtl; "rsIncandescent..." y "rsMaterial3SG" son materiales de Redshift
// que Maya no supo exportar bien (salen con color negro y sin imagen).
void darAspectoAlCarrusel(ModeloOBJ& carrusel)
{
    // Paleta: el archivo trae púrpura y rojo; el original usaba carmesí y amarillo.
    carrusel.ponerColor("lambert5SG", COLOR_CARMESI);    // base, corona, cono y gajos del techo
    carrusel.ponerColor("lambert4SG", COLOR_AMARILLO);   // los otros gajos del techo y detalles

    // Piso de la plataforma: sale negro; en el original lleva franjas radiales.
    carrusel.ponerFranjasRadiales("rsMaterial3SG", FRANJAS_DE_LA_PLATAFORMA, COLOR_CARMESI, COLOR_AMARILLO);

    // Paneles ilustrados del borde del techo. Qué imagen va en cada material lo guarda el FBX del
    // modelo (conexiones textura -> material); el OBJ lo perdió. Su brillo propio cambia entre el día
    // y la noche (ver aplicarAmbiente).
    carrusel.ponerTextura("rsIncandescent1SG", "modelos/map_d.jpg");   // niños en una cebra
    carrusel.ponerTextura("rsIncandescent2SG", "modelos/map_c.jpg");   // niño en un tren

    // Medallones ilustrados de la columna central (salían negros). Son los materiales "surfaceShader";
    // por su cantidad de caras (3:3:2) corresponden a las otras tres imágenes del FBX.
    carrusel.ponerTextura("surfaceShader1SG", "modelos/map_b.jpg");   // niños y un girasol
    carrusel.ponerTextura("surfaceShader2SG", "modelos/map_a.jpg");   // niño en un columpio
    carrusel.ponerTextura("surfaceShader3SG", "modelos/map_c.jpg");   // niño en un tren

    // Bombillas del techo y de los bordes: miles de esferitas de color cálido (cuánto brillan,
    // lo decide aplicarAmbiente según sea de día o de noche).
    for (const char* material : BOMBILLAS_DEL_MODELO)
        carrusel.ponerColor(material, COLOR_BOMBILLAS_ENCENDIDAS);
}

// Matriz "model" que lleva un modelo (que viene en sus propias unidades y con su propio
// centro) al mundo: escalado para tener la altura pedida, centrado en x/z y apoyado en el piso.
glm::mat4 colocarEnElMundo(const LimitesModelo& caja, float altura)
{
    const float escala = altura / (caja.maximo.y - caja.minimo.y);

    const glm::vec3 centroDeLaBase((caja.minimo.x + caja.maximo.x) / 2.0f,
                                   caja.minimo.y,
                                   (caja.minimo.z + caja.maximo.z) / 2.0f);

    // Se aplica de derecha a izquierda: primero llevar el centro de la base al origen, luego escalar.
    return glm::scale(glm::mat4(1.0f), glm::vec3(escala)) *
           glm::translate(glm::mat4(1.0f), -centroDeLaBase);
}

// Dibuja una esfera unitaria escalada y colocada en "posicion", con el shader emisivo activo.
void dibujarFuenteDeLuz(const Shader& shaderEmisivo, const Malla& esferaUnitaria,
                        const glm::vec3& posicion, float radio, const glm::vec3& color)
{
    glm::mat4 modelo = glm::translate(glm::mat4(1.0f), posicion);
    modelo = glm::scale(modelo, glm::vec3(radio));

    shaderEmisivo.setMat4("model", modelo);
    shaderEmisivo.setVec3("colorEmitido", color);
    esferaUnitaria.dibujar();
}

// Carga los recursos y ejecuta el bucle de dibujo. Todo lo que vive en la GPU
// (shaders y mallas) se libera al salir de esta función, MIENTRAS el contexto
// de OpenGL todavía existe; por eso va separada de main().
void ejecutarEscena(GLFWwindow* ventana)
{
    // --- Recursos -----------------------------------------------------------
    Shader shaderEscena("escena.vs", "escena.fs");
    Shader shaderEmisivo("emisivo.vs", "emisivo.fs");

    ModeloOBJ modelo(RUTA_MODELO, GRUPOS_IGNORADOS);
    darAspectoAlCarrusel(modelo);

    const Malla piso = crearPiso(LADO_PISO, CASILLAS_PISO, COLOR_PISO_A, COLOR_PISO_B);
    const Malla esferaUnitaria = crearEsfera(1.0f, 32, 16, glm::vec3(1.0f));

    Iluminacion iluminacion = crearIluminacion();

    const glm::mat4 matrizModelo = colocarEnElMundo(modelo.limites(), ALTURA_MODELO);

    camara.MovementSpeed = VELOCIDAD_CAMARA;

    // Cargar un modelo grande tarda un par de segundos: la ventana estaba oculta para no verse
    // congelada y en blanco. Ahora que todo está listo, se muestra.
    glfwShowWindow(ventana);

    // --- Bucle de dibujo ----------------------------------------------------
    while (!glfwWindowShouldClose(ventana))
    {
        const float cuadroActual = static_cast<float>(glfwGetTime());
        deltaTiempo = cuadroActual - ultimoCuadro;
        ultimoCuadro = cuadroActual;

        procesarEntrada(ventana);

        // Día <-> noche: nocturnidad se acerca a 0 (día) o a 1 (noche) sin saltos bruscos, y con
        // smoothstep el cambio arranca y termina suave. Con ese avance se mezclan DIA y NOCHE.
        const float objetivo = esDeNoche ? 1.0f : 0.0f;
        const float paso = deltaTiempo / SEGUNDOS_DE_TRANSICION;
        nocturnidad = (nocturnidad < objetivo) ? std::min(nocturnidad + paso, objetivo)
                                               : std::max(nocturnidad - paso, objetivo);
        const Ambiente ambiente = mezclar(DIA, NOCHE, glm::smoothstep(0.0f, 1.0f, nocturnidad));
        aplicarAmbiente(ambiente, iluminacion, modelo);

        glClearColor(ambiente.colorCielo.r, ambiente.colorCielo.g, ambiente.colorCielo.b, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        const glm::mat4 proyeccion = glm::perspective(glm::radians(camara.Zoom), aspecto, 0.1f, 100.0f);
        const glm::mat4 vista = camara.GetViewMatrix();

        // 1) Objetos iluminados: piso y modelo.
        shaderEscena.use();
        shaderEscena.setMat4("projection", proyeccion);
        shaderEscena.setMat4("view", vista);
        shaderEscena.setVec3("posicionCamara", camara.Position);
        iluminacion.enviarA(shaderEscena);

        // El piso ya está en tamaño real: su matriz "model" es la identidad.
        shaderEscena.setMat4("model", glm::mat4(1.0f));
        MATERIAL_PISO.enviarA(shaderEscena);
        piso.dibujar();

        shaderEscena.setMat4("model", matrizModelo);
        MATERIAL_MODELO.enviarA(shaderEscena);
        modelo.dibujar(shaderEscena);

        // 2) Objetos que emiten luz: el Sol (o la luna) y, si se pide, una esfera en cada bombilla. No se iluminan.
        shaderEmisivo.use();
        shaderEmisivo.setMat4("projection", proyeccion);
        shaderEmisivo.setMat4("view", vista);

        // El Sol se dibuja siempre a la misma distancia de la cámara: así, aunque
        // caminemos, no nos acercamos a él (está "infinitamente" lejos).
        const glm::vec3 posicionSol = camara.Position + HACIA_EL_SOL * DISTANCIA_SOL;
        dibujarFuenteDeLuz(shaderEmisivo, esferaUnitaria, posicionSol, RADIO_SOL, ambiente.colorDelDisco);

        if (DIBUJAR_ESFERAS_DE_LUZ)
        {
            for (const LuzPuntual& bombilla : iluminacion.luces)
                dibujarFuenteDeLuz(shaderEmisivo, esferaUnitaria, bombilla.posicion, RADIO_BOMBILLA, bombilla.color);
        }

        // Mostrar lo dibujado y atender eventos (teclado, ratón, cierre de ventana).
        glfwSwapBuffers(ventana);
        glfwPollEvents();
    }
}

int main()
{
    // glfw: inicializar y configurar
    // ------------------------------
    if (!glfwInit())
    {
        std::cerr << "No se pudo inicializar GLFW" << std::endl;
        return -1;
    }
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_SAMPLES, 4);   // suaviza los bordes (antialiasing 4x)
    glfwWindowHint(GLFW_VISIBLE, GLFW_FALSE);   // la ventana se muestra cuando el modelo ya cargó (ver ejecutarEscena)

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // glfw: crear la ventana
    // ----------------------
    GLFWwindow* ventana = glfwCreateWindow(ANCHO_VENTANA, ALTO_VENTANA, "Carrusel", NULL, NULL);
    if (ventana == NULL)
    {
        std::cerr << "No se pudo crear la ventana de GLFW" << std::endl;
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(ventana);
    glfwSwapInterval(1);   // sincroniza con el monitor (vsync)
    glfwSetFramebufferSizeCallback(ventana, framebuffer_size_callback);
    glfwSetCursorPosCallback(ventana, mouse_callback);
    glfwSetScrollCallback(ventana, scroll_callback);
    glfwSetKeyCallback(ventana, key_callback);

    // GLFW captura el ratón para poder girar la cámara sin límites
    glfwSetInputMode(ventana, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // glad: cargar los punteros a las funciones de OpenGL
    // ---------------------------------------------------
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
    {
        std::cerr << "No se pudo inicializar GLAD" << std::endl;
        glfwTerminate();
        return -1;
    }

    // Estado global de OpenGL
    glEnable(GL_DEPTH_TEST);    // lo que está más cerca tapa a lo que está detrás
    glEnable(GL_MULTISAMPLE);

    int resultado = 0;
    try
    {
        ejecutarEscena(ventana);
    }
    catch (const std::exception& error)
    {
        std::cerr << "Error: " << error.what() << std::endl;
        resultado = -1;
    }

    glfwTerminate();
    return resultado;
}

// Atender el teclado: consultar a GLFW qué teclas están presionadas en este cuadro
// ---------------------------------------------------------------------------------
void procesarEntrada(GLFWwindow* ventana)
{
    if (glfwGetKey(ventana, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(ventana, true);

    if (glfwGetKey(ventana, GLFW_KEY_W) == GLFW_PRESS)
        camara.ProcessKeyboard(FORWARD, deltaTiempo);
    if (glfwGetKey(ventana, GLFW_KEY_S) == GLFW_PRESS)
        camara.ProcessKeyboard(BACKWARD, deltaTiempo);
    if (glfwGetKey(ventana, GLFW_KEY_A) == GLFW_PRESS)
        camara.ProcessKeyboard(LEFT, deltaTiempo);
    if (glfwGetKey(ventana, GLFW_KEY_D) == GLFW_PRESS)
        camara.ProcessKeyboard(RIGHT, deltaTiempo);
}

// glfw: se llama cuando cambia el tamaño de la ventana (por el sistema o el usuario)
// ---------------------------------------------------------------------------------
void framebuffer_size_callback(GLFWwindow* /*ventana*/, int ancho, int alto)
{
    // Ajustar el área de dibujo al nuevo tamaño. (En pantallas retina, ancho y alto
    // son bastante mayores que el tamaño pedido de la ventana.)
    glViewport(0, 0, ancho, alto);

    if (alto > 0)   // alto es 0 mientras la ventana está minimizada
        aspecto = static_cast<float>(ancho) / alto;
}

// glfw: se llama cada vez que se mueve el ratón
// ---------------------------------------------
void mouse_callback(GLFWwindow* /*ventana*/, double xposEntrada, double yposEntrada)
{
    const float xpos = static_cast<float>(xposEntrada);
    const float ypos = static_cast<float>(yposEntrada);

    if (primerMovimientoMouse)
    {
        ultimoX = xpos;
        ultimoY = ypos;
        primerMovimientoMouse = false;
    }

    const float desplazamientoX = xpos - ultimoX;
    const float desplazamientoY = ultimoY - ypos;   // invertido: en pantalla la Y crece hacia abajo

    ultimoX = xpos;
    ultimoY = ypos;

    camara.ProcessMouseMovement(desplazamientoX, desplazamientoY);
}

// glfw: se llama una vez cada vez que se pulsa o se suelta una tecla. Se usa para las acciones que
// ocurren UNA vez por pulsación (alternar día/noche); procesarEntrada() es para lo que se mantiene.
// ---------------------------------------------------------------------------------------------
void key_callback(GLFWwindow* /*ventana*/, int tecla, int /*codigoDeTecla*/, int accion, int /*modificadores*/)
{
    if (tecla == GLFW_KEY_N && accion == GLFW_PRESS)
        esDeNoche = !esDeNoche;
}

// glfw: se llama cada vez que se gira la rueda del ratón
// ------------------------------------------------------
void scroll_callback(GLFWwindow* /*ventana*/, double /*xoffset*/, double yoffset)
{
    camara.ProcessMouseScroll(static_cast<float>(yoffset));
}
