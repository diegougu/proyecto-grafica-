#version 330 core
out vec4 FragColor;

in vec3 PosicionMundo;
in vec3 NormalMundo;
in vec3 ColorVertice;
in vec2 UV;

// ---- Luces (deben coincidir con iluminacion.h) ------------------------------
#define MAX_LUCES_PUNTUALES 12

struct LuzSolar
{
    vec3 direccion;   // hacia dónde viaja la luz
    vec3 color;
};

struct LuzPuntual
{
    vec3 posicion;
    vec3 color;
    float constante;
    float lineal;
    float cuadratica;
};

uniform vec3 luzAmbiente;
uniform LuzSolar sol;
uniform LuzPuntual luces[MAX_LUCES_PUNTUALES];
uniform int cantidadLuces;

// ---- Cámara y material ------------------------------------------------------
uniform vec3 posicionCamara;
uniform float intensidadEspecular;
uniform float brillo;

// ---- Aspecto de cada pieza del modelo (ver ModeloOBJ) -----------------------
uniform bool usarColorPieza;    // true: el color es colorPieza (modelo); false: el de cada vértice (piso)
uniform vec3 colorPieza;

uniform bool usarTextura;       // true: se pega la imagen "textura" sobre el color
uniform sampler2D textura;

uniform float luzPropia;        // 0 = no emite luz; 1 = suma su color completo (bombillas encendidas)

uniform int franjas;            // > 0: franjas radiales (gajos) que alternan colorFranjaA / colorFranjaB
uniform vec3 colorFranjaA;
uniform vec3 colorFranjaB;

const float PI = 3.14159265359;

// Cuánta luz de color "colorLuz" refleja este punto de la superficie.
//   haciaLuz:     vector unitario desde el punto hacia la luz
//   haciaCamara:  vector unitario desde el punto hacia la cámara
vec3 iluminar(vec3 colorLuz, vec3 haciaLuz, vec3 normal, vec3 haciaCamara, vec3 colorBase)
{
    // Difusa: la superficie se ve más clara cuanto más de frente recibe la luz.
    float difusa = max(dot(normal, haciaLuz), 0.0);

    // Especular (modelo Blinn-Phong): el reflejo brillante aparece cuando la normal
    // apunta justo a la mitad entre la luz y la cámara. Solo si la luz llega por delante.
    float especular = 0.0;
    if (difusa > 0.0)
    {
        vec3 mitad = normalize(haciaLuz + haciaCamara);
        especular = intensidadEspecular * pow(max(dot(normal, mitad), 0.0), brillo);
    }

    // El reflejo especular es del color de la luz; el difuso, del color del objeto.
    return colorLuz * (difusa * colorBase + especular);
}

void main()
{
    vec3 haciaCamara = normalize(posicionCamara - PosicionMundo);

    // Iluminación de doble cara: si la normal apunta en sentido contrario a la cámara
    // (láminas delgadas vistas por su "revés", mallas cuyas caras están orientadas al
    // revés), se invierte. Así la cara visible siempre se ilumina como cara frontal.
    vec3 normal = normalize(NormalMundo);
    if (dot(normal, haciaCamara) < 0.0)
        normal = -normal;

    // Color "de pintura" de este punto: el del material, o el de la textura si la pieza la tiene.
    // La textura se mezcla según su transparencia (alfa): donde es opaca tapa al color y donde
    // es transparente (un PNG con fondo transparente) se sigue viendo el color de la pieza.
    vec3 colorBase = usarColorPieza ? colorPieza : ColorVertice;

    if (franjas > 0)
    {
        // Gajos de pizza alrededor del eje vertical: el número de gajo sale del ángulo del punto.
        float angulo = atan(PosicionMundo.z, PosicionMundo.x);                  // -pi .. pi
        float gajo = floor((angulo + PI) / (2.0 * PI) * float(franjas));
        colorBase = (mod(gajo, 2.0) < 1.0) ? colorFranjaA : colorFranjaB;
    }

    if (usarTextura)
    {
        vec4 muestra = texture(textura, UV);
        colorBase = mix(colorBase, muestra.rgb, muestra.a);
    }

    // 1. Ambiente: luz mínima que llega de todos lados.
    vec3 resultado = luzAmbiente * colorBase;

    // 2. Sol: todos los rayos son paralelos, así que la dirección es la misma en toda la escena.
    vec3 haciaSol = -normalize(sol.direccion);
    resultado += iluminar(sol.color, haciaSol, normal, haciaCamara, colorBase);

    // 3. Bombillas: la dirección cambia en cada punto y la luz se debilita con la distancia.
    for (int i = 0; i < cantidadLuces; ++i)
    {
        vec3 haciaBombilla = luces[i].posicion - PosicionMundo;
        float distancia = length(haciaBombilla);
        float atenuacion = 1.0 / (luces[i].constante
                                + luces[i].lineal * distancia
                                + luces[i].cuadratica * distancia * distancia);

        resultado += atenuacion * iluminar(luces[i].color, haciaBombilla / distancia,
                                           normal, haciaCamara, colorBase);
    }

    // 4. Luz propia: las piezas "encendidas" (bombillas, paneles) suman su color sin depender de ninguna luz.
    resultado += colorBase * luzPropia;

    FragColor = vec4(resultado, 1.0);
}
