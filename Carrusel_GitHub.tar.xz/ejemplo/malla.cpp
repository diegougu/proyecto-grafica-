#include "malla.h"

#include <glad/glad.h>

#include <cmath>
#include <cstddef>
#include <utility>

// ---------------------------------------------------------------------------
// Malla
// ---------------------------------------------------------------------------

Malla::Malla(const std::vector<Vertice>& vertices)
    : cantidadVertices_(static_cast<int>(vertices.size()))
{
    glGenVertexArrays(1, &vao_);
    glGenBuffers(1, &vbo_);

    glBindVertexArray(vao_);

    // Copiamos los vértices a la GPU una sola vez (GL_STATIC_DRAW: no cambian).
    glBindBuffer(GL_ARRAY_BUFFER, vbo_);
    glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(Vertice), vertices.data(), GL_STATIC_DRAW);

    // Le explicamos a OpenGL cómo leer un Vertice: tres atributos de 3 floats y uno de 2.
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertice), (void*)offsetof(Vertice, posicion));
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertice), (void*)offsetof(Vertice, normal));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, sizeof(Vertice), (void*)offsetof(Vertice, color));
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(3, 2, GL_FLOAT, GL_FALSE, sizeof(Vertice), (void*)offsetof(Vertice, uv));
    glEnableVertexAttribArray(3);

    glBindVertexArray(0);
}

Malla::~Malla()
{
    liberar();
}

Malla::Malla(Malla&& otra) noexcept
    : vao_(std::exchange(otra.vao_, 0)),
      vbo_(std::exchange(otra.vbo_, 0)),
      cantidadVertices_(std::exchange(otra.cantidadVertices_, 0))
{
}

Malla& Malla::operator=(Malla&& otra) noexcept
{
    if (this != &otra)
    {
        liberar();
        vao_ = std::exchange(otra.vao_, 0);
        vbo_ = std::exchange(otra.vbo_, 0);
        cantidadVertices_ = std::exchange(otra.cantidadVertices_, 0);
    }
    return *this;
}

void Malla::dibujar() const
{
    glBindVertexArray(vao_);
    glDrawArrays(GL_TRIANGLES, 0, cantidadVertices_);
}

void Malla::liberar()
{
    // Borrar el id 0 está permitido (no hace nada): sirve para mallas "movidas".
    glDeleteVertexArrays(1, &vao_);
    glDeleteBuffers(1, &vbo_);
    vao_ = vbo_ = 0;
}

// ---------------------------------------------------------------------------
// Piso
// ---------------------------------------------------------------------------

Malla crearPiso(float lado, int casillas, const glm::vec3& colorA, const glm::vec3& colorB)
{
    const glm::vec3 arriba(0.0f, 1.0f, 0.0f);
    const glm::vec2 sinUV(0.0f);   // el piso no lleva textura
    const float tamanoCasilla = lado / casillas;
    const float inicio = -lado / 2.0f;

    std::vector<Vertice> vertices;
    vertices.reserve(static_cast<size_t>(casillas) * casillas * 6);

    for (int i = 0; i < casillas; ++i)
    {
        for (int j = 0; j < casillas; ++j)
        {
            // Las casillas se alternan entre los dos colores, como un tablero.
            const glm::vec3& color = ((i + j) % 2 == 0) ? colorA : colorB;

            const float x0 = inicio + i * tamanoCasilla, x1 = x0 + tamanoCasilla;
            const float z0 = inicio + j * tamanoCasilla, z1 = z0 + tamanoCasilla;

            // Los dos triángulos de la casilla, en sentido antihorario visto desde arriba.
            const Vertice a{{x0, 0.0f, z0}, arriba, color, sinUV};
            const Vertice b{{x0, 0.0f, z1}, arriba, color, sinUV};
            const Vertice c{{x1, 0.0f, z1}, arriba, color, sinUV};
            const Vertice d{{x1, 0.0f, z0}, arriba, color, sinUV};
            vertices.insert(vertices.end(), {a, b, c,  a, c, d});
        }
    }
    return Malla(vertices);
}

// ---------------------------------------------------------------------------
// Esfera
// ---------------------------------------------------------------------------

Malla crearEsfera(float radio, int segmentos, int anillos, const glm::vec3& color)
{
    const float pi = 3.14159265358979f;

    // Punto de la esfera para el "anillo" (latitud) y el "segmento" (longitud) dados.
    auto punto = [&](int anillo, int segmento)
    {
        const float latitud  = pi * anillo / anillos;          // 0 (polo norte) .. pi (polo sur)
        const float longitud = 2.0f * pi * segmento / segmentos;
        const glm::vec3 direccion(std::sin(latitud) * std::cos(longitud),
                                  std::cos(latitud),
                                  std::sin(latitud) * std::sin(longitud));
        // En una esfera, la normal es simplemente la dirección desde el centro.
        return Vertice{direccion * radio, direccion, color, glm::vec2(0.0f)};   // sin textura
    };

    std::vector<Vertice> vertices;
    vertices.reserve(static_cast<size_t>(segmentos) * anillos * 6);

    for (int r = 0; r < anillos; ++r)
    {
        for (int s = 0; s < segmentos; ++s)
        {
            const Vertice a = punto(r, s),         b = punto(r + 1, s);
            const Vertice c = punto(r + 1, s + 1), d = punto(r, s + 1);
            // Antihorario visto desde afuera de la esfera.
            vertices.insert(vertices.end(), {a, c, b,  a, d, c});
        }
    }
    return Malla(vertices);
}
