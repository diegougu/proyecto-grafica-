#include "iluminacion.h"

#include <algorithm>
#include <iostream>
#include <string>

void Iluminacion::enviarA(const Shader& shader) const
{
    shader.setVec3("luzAmbiente", ambiente);

    shader.setVec3("sol.direccion", glm::normalize(sol.direccion));
    shader.setVec3("sol.color", sol.color);

    const int cantidad = static_cast<int>(std::min<size_t>(luces.size(), MAX_LUCES_PUNTUALES));
    if (static_cast<size_t>(cantidad) < luces.size())
    {
        static bool yaAvisado = false;   // avisamos una sola vez, no en cada cuadro
        if (!yaAvisado)
        {
            std::cerr << "Aviso: hay " << luces.size() << " bombillas, pero el maximo es "
                      << MAX_LUCES_PUNTUALES << ". Las demas se ignoran." << std::endl;
            yaAvisado = true;
        }
    }
    shader.setInt("cantidadLuces", cantidad);

    // Los arreglos de uniforms se llenan elemento por elemento: "luces[0].posicion", ...
    for (int i = 0; i < cantidad; ++i)
    {
        const std::string luz = "luces[" + std::to_string(i) + "].";
        shader.setVec3(luz + "posicion", luces[i].posicion);
        shader.setVec3(luz + "color", luces[i].color);
        shader.setFloat(luz + "constante", luces[i].constante);
        shader.setFloat(luz + "lineal", luces[i].lineal);
        shader.setFloat(luz + "cuadratica", luces[i].cuadratica);
    }
}

void Material::enviarA(const Shader& shader) const
{
    shader.setFloat("intensidadEspecular", intensidadEspecular);
    shader.setFloat("brillo", brillo);
}
