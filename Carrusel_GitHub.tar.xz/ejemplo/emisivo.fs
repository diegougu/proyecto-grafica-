#version 330 core
out vec4 FragColor;

// Objetos que EMITEN luz (el Sol y las bombillas): se pintan de un color plano,
// sin sombreado, para que se vean "encendidos".
uniform vec3 colorEmitido;

void main()
{
    FragColor = vec4(colorEmitido, 1.0);
}
