// modelo_obj.h
// ---------------------------------------------------------------------------
// Un modelo en formato Wavefront OBJ (+ su archivo de materiales MTL), listo
// para dibujar.
//
//   ModeloOBJ carrusel("modelos/Xuan_Zhuan_Mu_Ma.obj", {"pSphere1"});
//   carrusel.ponerColor("lambert5SG", glm::vec3(0.9f, 0.1f, 0.3f));
//   carrusel.ponerTextura("rsIncandescent1SG", "modelos/map_d.jpg");
//   ...
//   carrusel.dibujar(shaderEscena);
//
// El modelo se divide en PIEZAS: una por cada material del MTL. Todas las
// caras que comparten material forman una sola pieza (un solo "dibujado"),
// aunque vengan de miles de grupos distintos del OBJ. Los métodos ponerXxx()
// cambian el aspecto de una pieza por el nombre de su material.
//
// De cada material se usa por defecto:
//   - Kd:     el color difuso
//   - map_Kd: la textura (imagen) del MTL, si tiene; se busca junto al .obj
// Del OBJ se usan la geometría (se triangula si hace falta), las coordenadas
// de textura (UV) y las normales. Si el archivo no trae normales, se
// calculan suavizadas.
// NO se usan: brillo, transparencia, mapas de relieve ni de especular del MTL.
//
// Muchos exportadores (Maya, por ejemplo) pierden datos al escribir el MTL:
// materiales sin su textura o con color negro. Los métodos ponerXxx() sirven
// para devolverles el aspecto que tenían en el original.
//
// El modelo conserva sus unidades originales. Para llevarlo al tamaño y la
// posición del mundo usa limites() y la matriz "model" (ver main.cpp).
// ---------------------------------------------------------------------------
#ifndef MODELO_OBJ_H
#define MODELO_OBJ_H

#include "malla.h"
#include "textura.h"

#include <learnopengl/shader_m.h>

#include <glm/glm.hpp>

#include <functional>
#include <map>
#include <string>
#include <vector>

// La caja más pequeña (alineada con los ejes) que contiene al modelo.
struct LimitesModelo
{
    glm::vec3 minimo;
    glm::vec3 maximo;
};

class ModeloOBJ
{
public:
    // gruposIgnorados: nombres de grupos del OBJ (líneas "g nombre") que NO se cargan.
    //   Sirve para descartar restos de la escena original, como una cúpula de cielo.
    // Lanza std::runtime_error si el archivo no se puede leer.
    explicit ModeloOBJ(const std::string& rutaObj, const std::vector<std::string>& gruposIgnorados = {});

    // ---- Aspecto de las piezas ------------------------------------------------
    // "nombreMaterial" es el nombre del material en el MTL. Se acepta sin el prefijo
    // que Maya le antepone con ":" ("lambert5SG" sirve para "Escena:lambert5SG").
    // Si el modelo no tiene ese material, avisa por consola.

    // Cambia el color de la pieza.
    void ponerColor(const std::string& nombreMaterial, const glm::vec3& color);

    // Pega una imagen sobre la pieza (usa las UV del modelo; la imagen se repite fuera de [0,1]).
    // Si la imagen tiene partes transparentes, ahí se sigue viendo el color. Cada archivo se
    // carga una sola vez aunque se use en varias piezas. Si no se puede leer, avisa y la pieza
    // conserva su color.
    void ponerTextura(const std::string& nombreMaterial, const std::string& rutaImagen);

    // Hace que la pieza emita luz propia: se ve "encendida" sin depender de ninguna luz.
    //   intensidad: 0 = no emite; 1 = se suma su color completo a lo que ya recibe de las luces.
    void ponerLuzPropia(const std::string& nombreMaterial, float intensidad);

    // Pinta la pieza con franjas radiales (como los gajos de una pizza) que se alternan entre
    // dos colores, alrededor del eje vertical del mundo (por eso el modelo debe estar centrado
    // en el origen). "cantidad" debe ser par; reemplaza al color y a la textura de la pieza.
    void ponerFranjasRadiales(const std::string& nombreMaterial, int cantidad,
                              const glm::vec3& colorA, const glm::vec3& colorB);

    // Caja que contiene todo lo que se dibuja (sin contar los grupos ignorados).
    LimitesModelo limites() const { return limites_; }

    // Dibuja todas las piezas con el shader activo (escena.fs: usa los uniforms
    // usarColorPieza, colorPieza, usarTextura, textura, luzPropia y franjas).
    // Quien llama envía antes la matriz "model".
    void dibujar(const Shader& shader) const;

private:
    struct Pieza
    {
        std::string material;
        Malla malla;
        glm::vec3 color;                          // color de la pieza (Kd del material, salvo que se cambie)
        const Textura* textura = nullptr;         // nullptr = se ve de su color
        float luzPropia = 0.0f;                   // 0 = no emite luz
        int franjas = 0;                          // 0 = sin franjas
        glm::vec3 colorFranjaA{0.0f};
        glm::vec3 colorFranjaB{0.0f};
    };

    // Aplica "cambio" a todas las piezas de ese material; avisa si no hay ninguna.
    void aCadaPieza(const std::string& nombreMaterial, const std::function<void(Pieza&)>& cambio);

    // Carga una imagen (o reutiliza la ya cargada). Devuelve nullptr, con aviso, si no se puede leer.
    const Textura* obtenerTextura(const std::string& rutaImagen);

    std::vector<Pieza> piezas_;
    std::map<std::string, Textura> texturas_;   // las imágenes ya cargadas, por ruta
    LimitesModelo limites_{glm::vec3(0.0f), glm::vec3(0.0f)};
};

#endif
