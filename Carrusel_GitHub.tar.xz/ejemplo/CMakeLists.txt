project( ejemplo_glfw )

set(PROJECT_FOLDER_NAME ejemplo)

message( "Source of application:  ${CMAKE_SOURCE_DIR} " )
message( "Subproject name:  ${PROJECT_NAME} " )

set(CMAKE_BINARY_DIR "${CMAKE_SOURCE_DIR}/bin")
set(EXECUTABLE_OUTPUT_PATH ${CMAKE_BINARY_DIR} )

# Enable C++11 / C++14 / C++17 / C++20
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED TRUE)
set(CMAKE_BUILD_TYPE Release )

link_libraries(glfw)

include_directories("${GLFW_SOURCE_DIR}/OwnProjects/${PROJECT_FOLDER_NAME}")
include_directories("${GLFW_SOURCE_DIR}/OwnProjects/${PROJECT_FOLDER_NAME}/glm")

if (MATH_LIBRARY)
	message(${MATH_LIBRARY})
    link_libraries("${MATH_LIBRARY}")
endif()

# Workaround for the MS CRT deprecating parts of the standard library
if (MSVC OR CMAKE_C_SIMULATE_ID STREQUAL "MSVC")
    add_definitions(-D_CRT_SECURE_NO_WARNINGS)
endif()

if (WIN32)
    set(ICON ../glfw.rc)
elseif (APPLE)
    set(ICON ../glfw.icns)
endif()

set(GLAD_GL "glad/glad.h" "glad/glad.c")

# OpenGL
find_package(OpenGL REQUIRED)

file(GLOB SOURCES "*.cpp" "*.c" )
file(GLOB HEADERS "*.hpp" "*.h" )
file(GLOB SHADERS "*.vert" "*.frag" "*.vs" "*.fs" )

add_executable(
 ${PROJECT_NAME} WIN32 MACOSX_BUNDLE  
 ${HEADERS} ${SOURCES} ${SHADERS}
 ${ICON} ${GLAD_GL}
 )

# Copy shaders files that match with *.vs and *.fs
file(COPY ${SHADERS} DESTINATION ${EXECUTABLE_OUTPUT_PATH})

# Copy the models and textures folders: the program loads "modelos/..." and "texturas/..." relative to bin/.
# Only what the program reads is copied (.obj, .mtl and the images next to them). Other formats of the same
# model (.fbx, .mb) and the original project folder (sourceimages) are skipped: they weigh hundreds of MB.
# (file(COPY) skips files that are already up to date, so the big .obj is not copied again on every run.)
file(COPY "${CMAKE_CURRENT_SOURCE_DIR}/modelos" DESTINATION ${EXECUTABLE_OUTPUT_PATH}
     FILES_MATCHING
     PATTERN "Xuan_Zhuan_Mu_Ma" EXCLUDE
     PATTERN "*.obj" PATTERN "*.mtl" PATTERN "*.jpg" PATTERN "*.png")
file(COPY "${CMAKE_CURRENT_SOURCE_DIR}/texturas" DESTINATION ${EXECUTABLE_OUTPUT_PATH})

message( "\nBuild mode test is: ${CMAKE_BUILD_TYPE}" )

#set(GUI_ONLY_BINARIES  ${PROJECT_NAME})

message( "\nBuild C++ standard is: ${CMAKE_CXX_STANDARD}" ) 

if (WIN32)
    set(SUBSYSTEM_LINK_FLAGS "-mconsole -mwindows")
    target_link_libraries(${PROJECT_NAME} ${SUBSYSTEM_LINK_FLAGS})
else()
    target_link_libraries(${PROJECT_NAME} OpenGL::GL)
endif()

