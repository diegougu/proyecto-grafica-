#include "modelo_obj.h"

// La librería tiny_obj_loader es un solo archivo .h. Esta línea le pide que
// incluya también su código; debe hacerse en UN solo .cpp de todo el proyecto.
#define TINYOBJLOADER_IMPLEMENTATION
#include "tiny_obj_loader.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <iostream>
#include <stdexcept>

namespace
{
    // Color de las caras que no tienen material asignado.
    const glm::vec3 COLOR_POR_DEFECTO(0.8f);
    const char* const NOMBRE_SIN_MATERIAL = "(sin material)";

    // Si dos triángulos vecinos forman un ángulo mayor a este, la unión entre
    // ellos se considera una arista "viva" (una esquina) y no se suaviza.
    const float ANGULO_MAXIMO_SUAVIZADO_GRADOS = 60.0f;

    // Clave para agrupar vértices por posición exacta (el OBJ repite los mismos
    // números de texto, así que los floats resultantes son idénticos).
    using ClavePosicion = std::array<float, 3>;
    ClavePosicion clave(const glm::vec3& p) { return {p.x, p.y, p.z}; }

    // Carpeta que contiene el archivo ("modelos/carrusel.obj" -> "modelos/").
    // El MTL y las imágenes que éste nombra se buscan ahí.
    std::string carpetaDe(const std::string& ruta)
    {
        const size_t barra = ruta.find_last_of("/\\");
        return (barra == std::string::npos) ? "" : ruta.substr(0, barra + 1);
    }

    // ¿El material del modelo se llama "nombre"? Se acepta sin el prefijo de espacio de nombres
    // de Maya: "lambert5SG" coincide con "MerryGoRoundSmmothFinal:lambert5SG".
    bool coincide(const std::string& materialDelModelo, const std::string& nombre)
    {
        if (materialDelModelo == nombre)
            return true;
        const std::string sufijo = ":" + nombre;
        return materialDelModelo.size() > sufijo.size() &&
               materialDelModelo.compare(materialDelModelo.size() - sufijo.size(), sufijo.size(), sufijo) == 0;
    }

    struct TriangulosLeidos
    {
        std::vector<Vertice> vertices;     // cada 3 consecutivos forman un triángulo
        std::vector<int> materialDeCada;   // material de cada triángulo (uno por cada 3 vértices); -1 = sin material
        bool faltanNormales = false;       // true si algún vértice no traía normal en el archivo
    };

    // Paso 1: convierte las "formas" (grupos del OBJ) en una lista de triángulos
    // con posición, UV y, si el archivo las trae, normal. (El color no va en el vértice:
    // es el mismo para toda la pieza de un material, ver el constructor de ModeloOBJ.)
    TriangulosLeidos leerTriangulos(const tinyobj::ObjReader& lector, const std::vector<std::string>& gruposIgnorados)
    {
        const tinyobj::attrib_t& atributos = lector.GetAttrib();

        TriangulosLeidos leidos;

        for (const tinyobj::shape_t& forma : lector.GetShapes())
        {
            if (std::find(gruposIgnorados.begin(), gruposIgnorados.end(), forma.name) != gruposIgnorados.end())
                continue;

            const tinyobj::mesh_t& malla = forma.mesh;

            // Como pedimos triangulate=true, cada cara tiene exactamente 3 índices.
            for (size_t cara = 0; cara < malla.num_face_vertices.size(); ++cara)
            {
                // Material de esta cara (-1 = sin material).
                const int idMaterial = malla.material_ids[cara];

                Vertice triangulo[3];
                bool faltaNormalEnEstaCara = false;
                for (int k = 0; k < 3; ++k)
                {
                    const tinyobj::index_t indice = malla.indices[3 * cara + k];
                    const tinyobj::real_t* p = &atributos.vertices[3 * indice.vertex_index];

                    // normal_index < 0 significa que el archivo no define normal para este vértice.
                    glm::vec3 normal(0.0f);
                    if (indice.normal_index >= 0)
                    {
                        const tinyobj::real_t* n = &atributos.normals[3 * indice.normal_index];
                        normal = glm::vec3(n[0], n[1], n[2]);
                    }
                    else
                    {
                        faltaNormalEnEstaCara = true;
                    }

                    // Igual con las coordenadas de textura: sin UV, (0,0).
                    glm::vec2 uv(0.0f);
                    if (indice.texcoord_index >= 0)
                    {
                        const tinyobj::real_t* t = &atributos.texcoords[2 * indice.texcoord_index];
                        uv = glm::vec2(t[0], t[1]);
                    }

                    triangulo[k] = Vertice{glm::vec3(p[0], p[1], p[2]), normal, glm::vec3(0.0f), uv};
                }

                // Algunos triángulos del archivo son "degenerados" (dos vértices en el
                // mismo punto, típico en los polos de una esfera). No se ven y no tienen
                // normal, así que los descartamos.
                const glm::vec3 area = glm::cross(triangulo[1].posicion - triangulo[0].posicion,
                                                  triangulo[2].posicion - triangulo[0].posicion);
                if (glm::length(area) < 1e-8f)
                    continue;

                leidos.faltanNormales |= faltaNormalEnEstaCara;
                leidos.vertices.insert(leidos.vertices.end(), triangulo, triangulo + 3);
                leidos.materialDeCada.push_back(idMaterial);
            }
        }
        return leidos;
    }

    // Paso 2 (solo si el archivo no trae normales): las calcula.
    //
    // Normal plana: la perpendicular de cada triángulo (producto cruz). Si
    // usáramos solo esa, el modelo se vería "facetado". Para verlo liso, cada
    // vértice promedia las normales de TODOS los triángulos que comparten su
    // posición, pero solo de los que apuntan casi en la misma dirección (así
    // los bordes duros, como la arista de una caja, se conservan).
    void calcularNormalesSuaves(std::vector<Vertice>& vertices)
    {
        const size_t cantidadTriangulos = vertices.size() / 3;

        // Normal plana de cada triángulo. NO se normaliza: su longitud es
        // proporcional al área, y así los triángulos grandes pesan más al promediar.
        std::vector<glm::vec3> normalesPlanas(cantidadTriangulos);
        for (size_t t = 0; t < cantidadTriangulos; ++t)
        {
            const glm::vec3& a = vertices[3 * t].posicion;
            const glm::vec3& b = vertices[3 * t + 1].posicion;
            const glm::vec3& c = vertices[3 * t + 2].posicion;
            normalesPlanas[t] = glm::cross(b - a, c - a);
        }

        // Para cada posición del modelo, qué triángulos la usan. (En el OBJ el mismo
        // punto aparece repetido en cada triángulo, por eso se agrupa por posición.)
        std::map<ClavePosicion, std::vector<size_t>> triangulosPorPosicion;
        for (size_t i = 0; i < vertices.size(); ++i)
            triangulosPorPosicion[clave(vertices[i].posicion)].push_back(i / 3);

        const float cosenoMinimo = std::cos(glm::radians(ANGULO_MAXIMO_SUAVIZADO_GRADOS));
        for (size_t i = 0; i < vertices.size(); ++i)
        {
            const glm::vec3 propia = glm::normalize(normalesPlanas[i / 3]);

            glm::vec3 suma(0.0f);
            for (size_t vecino : triangulosPorPosicion.at(clave(vertices[i].posicion)))
            {
                // dot() de dos vectores unitarios = coseno del ángulo entre ellos.
                if (glm::dot(propia, glm::normalize(normalesPlanas[vecino])) >= cosenoMinimo)
                    suma += normalesPlanas[vecino];
            }
            vertices[i].normal = glm::normalize(suma);
        }
    }

    LimitesModelo calcularLimites(const std::vector<Vertice>& vertices)
    {
        LimitesModelo limites{vertices.front().posicion, vertices.front().posicion};
        for (const Vertice& v : vertices)
        {
            limites.minimo = glm::min(limites.minimo, v.posicion);
            limites.maximo = glm::max(limites.maximo, v.posicion);
        }
        return limites;
    }
}

ModeloOBJ::ModeloOBJ(const std::string& rutaObj, const std::vector<std::string>& gruposIgnorados)
{
    const std::string carpeta = carpetaDe(rutaObj);

    tinyobj::ObjReaderConfig configuracion;
    configuracion.triangulate = true;
    configuracion.mtl_search_path = carpeta;

    tinyobj::ObjReader lector;
    if (!lector.ParseFromFile(rutaObj, configuracion))
    {
        throw std::runtime_error("No se pudo leer el modelo '" + rutaObj + "': " + lector.Error() +
                                 "\n(Las rutas son relativas a donde se ejecuta el programa: la carpeta bin/)");
    }
    if (!lector.Warning().empty())
        std::cerr << "Aviso al leer '" << rutaObj << "': " << lector.Warning() << std::endl;

    TriangulosLeidos leidos = leerTriangulos(lector, gruposIgnorados);
    if (leidos.vertices.empty())
        throw std::runtime_error("El modelo '" + rutaObj + "' no contiene triangulos");

    // Si el archivo trae normales (las del autor suelen ser mejores) se usan tal cual.
    if (leidos.faltanNormales)
        calcularNormalesSuaves(leidos.vertices);

    limites_ = calcularLimites(leidos.vertices);

    // Qué triángulos tiene cada material. (Un solo recorrido: un modelo puede tener
    // miles de materiales y millones de triángulos.)
    std::map<int, std::vector<size_t>> triangulosPorMaterial;
    for (size_t t = 0; t < leidos.materialDeCada.size(); ++t)
        triangulosPorMaterial[leidos.materialDeCada[t]].push_back(t);

    // Una pieza (una Malla) por material.
    const std::vector<tinyobj::material_t>& materiales = lector.GetMaterials();
    for (const auto& [idMaterial, triangulos] : triangulosPorMaterial)
    {
        std::vector<Vertice> verticesDelMaterial;
        verticesDelMaterial.reserve(triangulos.size() * 3);
        for (size_t t : triangulos)
            verticesDelMaterial.insert(verticesDelMaterial.end(),
                                       leidos.vertices.begin() + 3 * t, leidos.vertices.begin() + 3 * t + 3);

        Pieza pieza{NOMBRE_SIN_MATERIAL, Malla(verticesDelMaterial), COLOR_POR_DEFECTO};
        if (idMaterial >= 0)
        {
            const tinyobj::material_t& material = materiales[idMaterial];
            pieza.material = material.name;
            pieza.color = glm::vec3(material.diffuse[0], material.diffuse[1], material.diffuse[2]);
            if (!material.diffuse_texname.empty())
                pieza.textura = obtenerTextura(carpeta + material.diffuse_texname);
        }
        piezas_.push_back(std::move(pieza));
    }
}

const Textura* ModeloOBJ::obtenerTextura(const std::string& rutaImagen)
{
    auto encontrada = texturas_.find(rutaImagen);
    if (encontrada == texturas_.end())
    {
        try
        {
            encontrada = texturas_.emplace(rutaImagen, Textura(rutaImagen)).first;
        }
        catch (const std::runtime_error& error)
        {
            std::cerr << "Aviso: " << error.what() << "\n(esa pieza se vera del color de su material)" << std::endl;
            return nullptr;
        }
    }
    return &encontrada->second;
}

void ModeloOBJ::aCadaPieza(const std::string& nombreMaterial, const std::function<void(Pieza&)>& cambio)
{
    bool encontrado = false;
    for (Pieza& pieza : piezas_)
    {
        if (!coincide(pieza.material, nombreMaterial))
            continue;
        cambio(pieza);
        encontrado = true;
    }

    if (!encontrado)
        std::cerr << "Aviso: el modelo no tiene ningun material llamado '" << nombreMaterial << "'" << std::endl;
}

void ModeloOBJ::ponerColor(const std::string& nombreMaterial, const glm::vec3& color)
{
    aCadaPieza(nombreMaterial, [&](Pieza& pieza) { pieza.color = color; });
}

void ModeloOBJ::ponerTextura(const std::string& nombreMaterial, const std::string& rutaImagen)
{
    // La imagen se carga una sola vez (devuelve nullptr, con aviso, si no se puede leer).
    const Textura* textura = obtenerTextura(rutaImagen);
    aCadaPieza(nombreMaterial, [&](Pieza& pieza) { pieza.textura = textura; });
}

void ModeloOBJ::ponerLuzPropia(const std::string& nombreMaterial, float intensidad)
{
    aCadaPieza(nombreMaterial, [&](Pieza& pieza) { pieza.luzPropia = intensidad; });
}

void ModeloOBJ::ponerFranjasRadiales(const std::string& nombreMaterial, int cantidad,
                                     const glm::vec3& colorA, const glm::vec3& colorB)
{
    aCadaPieza(nombreMaterial, [&](Pieza& pieza)
    {
        pieza.franjas = cantidad;
        pieza.colorFranjaA = colorA;
        pieza.colorFranjaB = colorB;
    });
}

void ModeloOBJ::dibujar(const Shader& shader) const
{
    // El color del modelo viene de cada pieza (no del vértice, como en el piso).
    shader.setBool("usarColorPieza", true);

    for (const Pieza& pieza : piezas_)
    {
        shader.setVec3("colorPieza", pieza.color);

        shader.setBool("usarTextura", pieza.textura != nullptr);
        if (pieza.textura != nullptr)
        {
            pieza.textura->enlazar(0);    // unidad de textura 0...
            shader.setInt("textura", 0);  // ...que es la que lee el sampler "textura"
        }

        shader.setFloat("luzPropia", pieza.luzPropia);

        shader.setInt("franjas", pieza.franjas);
        if (pieza.franjas > 0)
        {
            shader.setVec3("colorFranjaA", pieza.colorFranjaA);
            shader.setVec3("colorFranjaB", pieza.colorFranjaB);
        }

        pieza.malla.dibujar();
    }

    // Dejamos el shader como lo encontramos: lo que se dibuje después (el piso) no debe heredar nada.
    shader.setBool("usarColorPieza", false);
    shader.setBool("usarTextura", false);
    shader.setFloat("luzPropia", 0.0f);
    shader.setInt("franjas", 0);
}
