#include "textura.h"

#include <glad/glad.h>

// stb_image es un solo archivo .h. Esta línea le pide que incluya también su
// código; debe hacerse en UN solo .cpp de todo el proyecto.
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#include <stdexcept>
#include <utility>

Textura::Textura(const std::string& rutaImagen)
{
    // Los archivos de imagen guardan la fila de arriba primero; OpenGL espera la de abajo.
    stbi_set_flip_vertically_on_load(true);

    // Pedimos siempre 4 canales (rojo, verde, azul, alfa) sin importar el formato original:
    // así el resto del código solo tiene que conocer un tipo de imagen.
    int ancho = 0, alto = 0, canalesOriginales = 0;
    unsigned char* pixeles = stbi_load(rutaImagen.c_str(), &ancho, &alto, &canalesOriginales, 4);
    if (pixeles == nullptr)
    {
        throw std::runtime_error("No se pudo leer la imagen '" + rutaImagen + "': " + stbi_failure_reason() +
                                 "\n(Las rutas son relativas a donde se ejecuta el programa: la carpeta bin/)");
    }

    glGenTextures(1, &id_);
    glBindTexture(GL_TEXTURE_2D, id_);

    // Al salirse de [0,1] la imagen se repite; al verse lejos usa versiones reducidas
    // de sí misma (mipmaps) para que no "parpadee".
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, ancho, alto, 0, GL_RGBA, GL_UNSIGNED_BYTE, pixeles);
    glGenerateMipmap(GL_TEXTURE_2D);

    stbi_image_free(pixeles);
}

Textura::~Textura()
{
    liberar();
}

Textura::Textura(Textura&& otra) noexcept
    : id_(std::exchange(otra.id_, 0))
{
}

Textura& Textura::operator=(Textura&& otra) noexcept
{
    if (this != &otra)
    {
        liberar();
        id_ = std::exchange(otra.id_, 0);
    }
    return *this;
}

void Textura::enlazar(unsigned int unidad) const
{
    glActiveTexture(GL_TEXTURE0 + unidad);
    glBindTexture(GL_TEXTURE_2D, id_);
}

void Textura::liberar()
{
    glDeleteTextures(1, &id_);   // borrar el id 0 está permitido (no hace nada)
    id_ = 0;
}
