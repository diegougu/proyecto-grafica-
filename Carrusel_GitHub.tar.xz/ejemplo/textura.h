// textura.h
// ---------------------------------------------------------------------------
// Una imagen cargada en la GPU, lista para "pegarse" sobre una pieza.
//
//   Textura madera("texturas/madera.png");
//   madera.enlazar(0);   // el shader la lee con "uniform sampler2D" (ver escena.fs)
//
// Formatos: PNG, JPG, BMP, TGA. Si la imagen tiene transparencia (PNG con
// canal alfa) se conserva.
//
// La imagen se REPITE al salirse de [0,1] (modo "repeat"): así una imagen
// pequeña puede cubrir una pieza grande, repetida como azulejos.
// ---------------------------------------------------------------------------
#ifndef TEXTURA_H
#define TEXTURA_H

#include <string>

class Textura
{
public:
    // Lanza std::runtime_error si el archivo no existe o no es una imagen válida.
    explicit Textura(const std::string& rutaImagen);
    ~Textura();

    // Es dueña de un objeto de OpenGL: se puede mover, no copiar.
    Textura(const Textura&) = delete;
    Textura& operator=(const Textura&) = delete;
    Textura(Textura&& otra) noexcept;
    Textura& operator=(Textura&& otra) noexcept;

    // Activa la textura en la "unidad" indicada (0, 1, 2...) para que el shader la pueda leer.
    void enlazar(unsigned int unidad = 0) const;

private:
    void liberar();

    unsigned int id_ = 0;
};

#endif
