#version 330 core

// Solo necesitamos la posición: estos objetos no se iluminan (ver emisivo.fs).
layout (location = 0) in vec3 aPosicion;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(aPosicion, 1.0);
}
