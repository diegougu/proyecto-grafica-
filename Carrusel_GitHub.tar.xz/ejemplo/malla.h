// malla.h
// ---------------------------------------------------------------------------
// Una Malla es un conjunto de triángulos ya cargado en la GPU.
// Todo lo que dibujamos en la escena (el carrusel, el piso, el Sol) es una
// Malla; solo cambia cómo se construyó:
//
//   - el carrusel viene de un archivo       -> ModeloOBJ  (modelo_obj.h; una Malla por material)
//   - el piso y las esferas se generan aquí -> crearPiso(), crearEsfera()
// ---------------------------------------------------------------------------
#ifndef MALLA_H
#define MALLA_H

#include <glm/glm.hpp>

#include <vector>

// Datos de cada vértice. El orden de los campos define los "atributos" del
// shader (layout location 0, 1, 2 y 3 en escena.vs).
struct Vertice
{
    glm::vec3 posicion;
    glm::vec3 normal;   // hacia dónde "mira" la superficie; la iluminación la necesita
    glm::vec3 color;    // color difuso (el "color de pintura" del objeto)
    glm::vec2 uv;       // a qué punto de una textura corresponde este vértice (0..1 = la imagen completa)
};

class Malla
{
public:
    // Cada 3 vértices consecutivos forman un triángulo.
    explicit Malla(const std::vector<Vertice>& vertices);
    ~Malla();

    // Una Malla es dueña de objetos de OpenGL (VAO/VBO): se puede mover, no copiar.
    Malla(const Malla&) = delete;
    Malla& operator=(const Malla&) = delete;
    Malla(Malla&& otra) noexcept;
    Malla& operator=(Malla&& otra) noexcept;

    // Dibuja con el shader activo (quien llama debe haber hecho shader.use()
    // y enviado la matriz "model").
    void dibujar() const;

private:
    void liberar();

    unsigned int vao_ = 0;
    unsigned int vbo_ = 0;
    int cantidadVertices_ = 0;
};

// Piso plano en y = 0, centrado en el origen, con casillas tipo tablero de
// ajedrez (ayuda a percibir la distancia y el movimiento de la cámara).
//   lado:     largo de cada lado del piso, en unidades del mundo
//   casillas: número de casillas por lado
Malla crearPiso(float lado, int casillas, const glm::vec3& colorA, const glm::vec3& colorB);

// Esfera centrada en el origen.
Malla crearEsfera(float radio, int segmentos, int anillos, const glm::vec3& color);

#endif
